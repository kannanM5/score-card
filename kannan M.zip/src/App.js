import "./App.css";
import { useSelector, useDispatch } from "react-redux";
import {
  increment_one,
  increment_two,
  increment_four,
  increment_six,
} from "./redux/action";
import { INCREMENT_ONE } from "./redux/actionTypes";

function App() {
  const arr = useSelector((state) => state.team);
  const myScore = useSelector((state) => state.total);
  const dispatch = useDispatch();

  const handleSubmitOne = () => {
    dispatch(increment_one);
  };

  return (
    <>
      <div>
        <h1 style={{ textAlign: "center" }}>Score Board</h1>
        <div className="tab">
          <table>
            <thead>
              <tr>
                <th>Players</th>
                <th>Score</th>
                <th>Wicket</th>
                <th>Add Score</th>
              </tr>
            </thead>
            <tbody>
              {arr.map((e, i) => {
                return (
                  <tr key={i}>
                    <td>{e.player}</td>
                    <td>{e.score}</td>
                    <td>{e.wicket}</td>
                    <td>
                      <button onClick={handleSubmitOne}>add1</button>
                      <button>add2</button>
                      <button>add4</button>
                      <button>add6</button>
                      <button>out</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <h2 style={{ textAlign: "center" }}>Total Score = {myScore}</h2>
      </div>
    </>
  );
}

export default App;
