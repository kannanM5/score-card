import {
  INCREMENT_ONE,
  INCREMENT_TWO,
  INCREMENT_FOUR,
  INCREMENT_SIX,
} from "./actionTypes";

const initialState = {
  team: [
    { player: "player1", score: 0, wicket: "Not Out" },
    { player: "player2", score: 0, wicket: "Not Out" },
    { player: "player3", score: 0, wicket: "Not Out" },
    { player: "player4", score: 0, wicket: "Not Out" },
    { player: "player5", score: 0, wicket: "Not Out" },
    { player: "player6", score: 0, wicket: "Not Out" },
    { player: "player7", score: 0, wicket: "Not Out" },
    { player: "player8", score: 0, wicket: "Not Out" },
    { player: "player9", score: 0, wicket: "Not Out" },
    { player: "player10", score: 0, wicket: "Not Out" },
    { player: "player11", score: 0, wicket: "Not Out" },
  ],
  total: 0,
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case INCREMENT_ONE:
      let count = state.team.score;
      return { ...state, count: count + 1 };
    case INCREMENT_TWO:
      return { ...state, score: count + 2 };
    case INCREMENT_FOUR:
      return { ...state, score: state.score + 4 };
    case INCREMENT_SIX:
      return { ...state, score: state.score + 6 };
    default:
      return state;
  }
};

export default reducer;
