import {
  INCREMENT_ONE,
  INCREMENT_TWO,
  INCREMENT_FOUR,
  INCREMENT_SIX,
} from "./actionTypes";

export const increment_one = () => {
  return {
    type: INCREMENT_ONE,
  };
};

export const increment_two = () => {
  return {
    type: INCREMENT_TWO,
  };
};

export const increment_four = () => {
  return {
    type: INCREMENT_FOUR,
  };
};

export const increment_six = () => {
  return {
    type: INCREMENT_SIX,
  };
};
